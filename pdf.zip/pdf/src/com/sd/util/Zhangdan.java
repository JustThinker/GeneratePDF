package com.sd.util;
 
public class Zhangdan 
{
 private String dyshuxing;
 private String fee ;
 private String sourcefee;
 private String shuilv;
 private String starttime;
 private String overtime;
 public Zhangdan(String dyshuxing,String fee,String sourcefee,String shuilv,String starttime,String overtime)
 {
  this.dyshuxing = dyshuxing;
  this.fee = fee;
  this.sourcefee = sourcefee;
  this.shuilv = shuilv;
  this.starttime = starttime;
  this.overtime = overtime;
 }
public String getDyshuxing() {
	return dyshuxing;
}
public void setDyshuxing(String dyshuxing) {
	this.dyshuxing = "单元名称";
}
public String getFee() {
	return fee;
}
public void setFee(String fee) {
	this.fee = fee;
}
public String getSourcefee() {
	return sourcefee;
}
public void setSourcefee(String sourcefee) {
	this.sourcefee = sourcefee;
}
public String getShuilv() {
	return shuilv;
}
public void setShuilv(String shuilv) {
	this.shuilv = shuilv;
}
public String getStarttime() {
	return starttime;
}
public void setStarttime(String starttime) {
	this.starttime = starttime;
}
public String getOvertime() {
	return overtime;
}
public void setOvertime(String overtime) {
	this.overtime = overtime;
}
   
}